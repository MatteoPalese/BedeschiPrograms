 -- NOTE D'USO --
 * non modificare, eliminare o aggiungere per nessun motivo gli elementi interni alla cartella 'Travelling App Folder';
 * per accedere all'applicazione, aprire la cartella e creare un collegamento dell'eseguibile 'Travelling Excel File Creator'
 * data la cartella "ingombrante", si può nascondere in questo modo:
      1. fare click destro sulla cartella;
      2. clicca "Proprietà";
      3. spuntare l'opzione "Nascosto" nella scheda apertasi;
      4. confermare cliccando "OK".
   Per rendere nuovamente visibile la cartella, si può abilitare la visualizzazione dei file nascosti: 
      1. da "Esplora file", cliccare "Questo PC";
      2. cliccare il disco rigido sul quale è stato salvata la cartella nascosta;
      3. cliccare su "Visualizza" nella parte superiore della scheda "Esplora file";
      4. nella sezione "Mostra/Nascondi", spuntare "Elementi nascosti".


 -- NOTE SULL'APP --
 * i valori decimali possono avere come separatore virgola o punto, entrambi utilizzabili contemporaneamente;
 * alla creazione di due file nello stesso minuto nella stessa cartella (ex: compilo e clicco due volte il testo di creazione 
   file scegliendo sempre la stessa cartella dove salvare), il secondo sovvrascriverà il primo, eliminandolo.


 -- GUIDA PER STAMPA DEI FILE CREATI (Microsoft Excel) --
 1. alla schermata di stampa, modificare i margini a "Margini stretti"
 2. alle opzioni di scala, scegliere "Adatta tutte le colonne su una pagina"

