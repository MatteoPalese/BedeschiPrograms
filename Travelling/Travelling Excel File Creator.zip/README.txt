ISTRUZIONI D'USO:
 - non modificare o spostare i file nella cartella;
 - per accedere all'applicazione, utilizza il suo collegamento che potrai spostare a piacimento;
 - i dati possono essere scritti con un punto o con una virgola come separatore decimale.

